package dao;

import bean.EmpManager;

public interface EmpManagerDao {
	public EmpManager select(String username);

}
